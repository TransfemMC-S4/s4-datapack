This is the Season Four data pack!

It is based off of the season three pack, but stripped down to its bare components for simple ways to make things work.
Anything that is not wanted still can be removed and modified to fit the new season.
